package com.example.diceapp

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val mybutton = findViewById<Button>(R.id.button)
        mybutton.setOnClickListener {
            dice_roll()
        }
    }

    // creating roll function
    private fun dice_roll() {
        //create a object for class dice
        val dice = Dice(6)
        val roll_dice = dice.roll_function()
        val imageview = findViewById<ImageView>(R.id.imageView)
        val textview1 = findViewById<TextView>(R.id.textView1)


        if (roll_dice == 1) {
            imageview.setImageResource(R.drawable.dice_1)
            textview1.setText("You rolled unlucky number !!!")
            textview1.setTextColor(Color.RED)
            Toast.makeText(this@MainActivity, "      1", Toast.LENGTH_SHORT).show()

        } else if (roll_dice == 2) {
            imageview.setImageResource(R.drawable.dice_2)
            textview1.setText("  You rolled lucky number !!!")
            textview1.setTextColor(Color.GREEN)
            Toast.makeText(this@MainActivity, "      2", Toast.LENGTH_SHORT).show()

        } else if (roll_dice == 3) {
            imageview.setImageResource(R.drawable.dice_3)
            textview1.setText("You rolled unlucky number !!!")
            textview1.setTextColor(Color.RED)
            Toast.makeText(this@MainActivity, "      3", Toast.LENGTH_SHORT).show()

        } else if (roll_dice == 4) {
            imageview.setImageResource(R.drawable.dice_4)
            textview1.setText("  You rolled lucky number !!!")
            textview1.setTextColor(Color.GREEN)
            Toast.makeText(this@MainActivity, "      4", Toast.LENGTH_SHORT).show()

        } else if (roll_dice == 5) {
            imageview.setImageResource(R.drawable.dice_5)
            textview1.setText("You rolled unlucky number !!!")
            textview1.setTextColor(Color.RED)
            Toast.makeText(this@MainActivity, "      5", Toast.LENGTH_SHORT).show()

        } else if (roll_dice == 6) {
            imageview.setImageResource(R.drawable.dice_6)
            textview1.setText("  You rolled lucky number !!!")
            textview1.setTextColor(Color.GREEN)
            Toast.makeText(this@MainActivity, "      6", Toast.LENGTH_SHORT).show()
        }

    }


    // creating a class name dice
    class Dice(var sides: Int) {
        fun roll_function(): Int {
            var dicerange = 1..6
            return (dicerange.random())
        }

    }
}